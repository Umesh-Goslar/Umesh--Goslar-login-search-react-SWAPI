# README #

STAR WARS LOGIN & SEARCH APP WITH SWAPI API

![Swapi Logo](https://ph-files.imgix.net/516f1efd-ac50-4c05-82f7-7336830265ad?auto=format&auto=compress&codec=mozjpeg&cs=strip)

### FEATURES ###

* LOGIN WITH REDUX-FORM
* TYPE-ALONG SEARCH WITH DEBOUCE AND THROTTLE

### How do I get set up? ###

* npm i
* npm run build [for prod]
* npm run build:dev [for dev]
* npm start
* npm test [for tests]

### Who do I talk to? ###

* Umesh G
